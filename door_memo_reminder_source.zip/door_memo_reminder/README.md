# Door Memo Reminder

Offline Android memo reminder app.

## Build APK using GitHub Actions

1. Upload these files to a GitHub repository.
2. Go to **Actions** tab.
3. Open **Build Flutter APK**.
4. Click **Run workflow**.
5. After build finishes, open the latest run.
6. Download artifact: `door-memo-reminder-apk`.
7. Extract ZIP and install `app-release.apk` on Android phone.

## Android Version

- minSdk: 23
- targetSdk: 35
- compileSdk: 35

## Features

- Add memo
- Save offline
- All orders
- Pending / Delivered
- Due / Paid
- Seen Date reminder
- Delivery Date reminder