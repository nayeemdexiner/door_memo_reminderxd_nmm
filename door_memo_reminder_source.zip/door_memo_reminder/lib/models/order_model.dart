class OrderModel {
  String id;
  String memoNo;
  String orderDate;
  String customerName;
  String address;
  String phone;
  String description;
  int quantity;
  double rate;
  double total;
  double advance;
  double due;
  String seenDate;
  String seenTime;
  String deliveryDate;
  String deliveryTime;
  String note;
  bool delivered;
  bool paid;
  bool seenDone;

  OrderModel({
    required this.id,
    required this.memoNo,
    required this.orderDate,
    required this.customerName,
    required this.address,
    required this.phone,
    required this.description,
    required this.quantity,
    required this.rate,
    required this.total,
    required this.advance,
    required this.due,
    required this.seenDate,
    required this.seenTime,
    required this.deliveryDate,
    required this.deliveryTime,
    required this.note,
    required this.delivered,
    required this.paid,
    required this.seenDone,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'memoNo': memoNo,
      'orderDate': orderDate,
      'customerName': customerName,
      'address': address,
      'phone': phone,
      'description': description,
      'quantity': quantity,
      'rate': rate,
      'total': total,
      'advance': advance,
      'due': due,
      'seenDate': seenDate,
      'seenTime': seenTime,
      'deliveryDate': deliveryDate,
      'deliveryTime': deliveryTime,
      'note': note,
      'delivered': delivered,
      'paid': paid,
      'seenDone': seenDone,
    };
  }

  factory OrderModel.fromMap(Map data) {
    return OrderModel(
      id: data['id'] ?? '',
      memoNo: data['memoNo'] ?? '',
      orderDate: data['orderDate'] ?? '',
      customerName: data['customerName'] ?? '',
      address: data['address'] ?? '',
      phone: data['phone'] ?? '',
      description: data['description'] ?? '',
      quantity: data['quantity'] ?? 0,
      rate: (data['rate'] ?? 0).toDouble(),
      total: (data['total'] ?? 0).toDouble(),
      advance: (data['advance'] ?? 0).toDouble(),
      due: (data['due'] ?? 0).toDouble(),
      seenDate: data['seenDate'] ?? '',
      seenTime: data['seenTime'] ?? '09:00',
      deliveryDate: data['deliveryDate'] ?? '',
      deliveryTime: data['deliveryTime'] ?? '09:00',
      note: data['note'] ?? '',
      delivered: data['delivered'] ?? false,
      paid: data['paid'] ?? false,
      seenDone: data['seenDone'] ?? false,
    );
  }
}