import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../services/database_service.dart';
import 'add_order_screen.dart';
import 'orders_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<OrderModel> orders = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    setState(() {
      orders = DatabaseService.getOrders();
    });
  }

  @override
  Widget build(BuildContext context) {
    final pending = orders.where((o) => !o.delivered).length;
    final delivered = orders.where((o) => o.delivered).length;
    final due = orders.where((o) => o.due > 0 && !o.paid).length;
    final paid = orders.where((o) => o.paid || o.due <= 0).length;
    final totalSale = orders.fold<double>(0, (p, o) => p + o.total);
    final totalDue = orders.fold<double>(0, (p, o) => p + (o.paid ? 0 : o.due));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Door Memo Reminder'),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: () async => load(),
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            const Text(
              'Dashboard',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 14),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.25,
              children: [
                _card('Total Orders', orders.length.toString(), Icons.receipt_long),
                _card('Pending', pending.toString(), Icons.pending_actions),
                _card('Delivered', delivered.toString(), Icons.check_circle),
                _card('Due Orders', due.toString(), Icons.money_off),
                _card('Paid Orders', paid.toString(), Icons.payments),
                _card('Total Due', totalDue.toStringAsFixed(0), Icons.warning),
              ],
            ),
            const SizedBox(height: 16),
            _wideCard('Total Sale', totalSale.toStringAsFixed(0)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: const Text('Add New Memo'),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddOrderScreen()),
                );
                load();
              },
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.list),
              label: const Text('All Orders'),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const OrdersScreen()),
                );
                load();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(String title, String value, IconData icon) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 28),
            const Spacer(),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text(title),
          ],
        ),
      ),
    );
  }

  Widget _wideCard(String title, String value) {
    return Card(
      elevation: 0,
      child: ListTile(
        leading: const Icon(Icons.trending_up),
        title: Text(title),
        trailing: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      ),
    );
  }
}