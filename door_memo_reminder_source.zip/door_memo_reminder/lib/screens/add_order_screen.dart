import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/order_model.dart';
import '../services/database_service.dart';
import '../services/notification_service.dart';

class AddOrderScreen extends StatefulWidget {
  final OrderModel? order;
  const AddOrderScreen({super.key, this.order});

  @override
  State<AddOrderScreen> createState() => _AddOrderScreenState();
}

class _AddOrderScreenState extends State<AddOrderScreen> {
  final formKey = GlobalKey<FormState>();

  final memo = TextEditingController();
  final name = TextEditingController();
  final address = TextEditingController();
  final phone = TextEditingController();
  final desc = TextEditingController();
  final qty = TextEditingController(text: '1');
  final rate = TextEditingController(text: '0');
  final advance = TextEditingController(text: '0');
  final note = TextEditingController();

  String orderDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
  String seenDate = '';
  String deliveryDate = '';
  String seenTime = '09:00';
  String deliveryTime = '09:00';
  bool delivered = false;
  bool paid = false;
  bool seenDone = false;

  @override
  void initState() {
    super.initState();
    final o = widget.order;
    if (o != null) {
      memo.text = o.memoNo;
      orderDate = o.orderDate;
      name.text = o.customerName;
      address.text = o.address;
      phone.text = o.phone;
      desc.text = o.description;
      qty.text = o.quantity.toString();
      rate.text = o.rate.toStringAsFixed(0);
      advance.text = o.advance.toStringAsFixed(0);
      seenDate = o.seenDate;
      deliveryDate = o.deliveryDate;
      seenTime = o.seenTime;
      deliveryTime = o.deliveryTime;
      note.text = o.note;
      delivered = o.delivered;
      paid = o.paid;
      seenDone = o.seenDone;
    }
  }

  double get total {
    final q = int.tryParse(qty.text) ?? 0;
    final r = double.tryParse(rate.text) ?? 0;
    return q * r;
  }

  double get due {
    final a = double.tryParse(advance.text) ?? 0;
    final d = total - a;
    return d < 0 ? 0 : d;
  }

  Future<void> pickDate(bool isSeen) async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2024),
      lastDate: DateTime(2035),
      initialDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        final value = DateFormat('yyyy-MM-dd').format(picked);
        if (isSeen) {
          seenDate = value;
        } else {
          deliveryDate = value;
        }
      });
    }
  }

  Future<void> pickTime(bool isSeen) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 9, minute: 0),
    );
    if (picked != null) {
      setState(() {
        final value =
            '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
        if (isSeen) {
          seenTime = value;
        } else {
          deliveryTime = value;
        }
      });
    }
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;

    final order = OrderModel(
      id: widget.order?.id ?? DateTime.now().millisecondsSinceEpoch.toString(),
      memoNo: memo.text.trim(),
      orderDate: orderDate,
      customerName: name.text.trim(),
      address: address.text.trim(),
      phone: phone.text.trim(),
      description: desc.text.trim(),
      quantity: int.tryParse(qty.text) ?? 0,
      rate: double.tryParse(rate.text) ?? 0,
      total: total,
      advance: double.tryParse(advance.text) ?? 0,
      due: due,
      seenDate: seenDate,
      seenTime: seenTime,
      deliveryDate: deliveryDate,
      deliveryTime: deliveryTime,
      note: note.text.trim(),
      delivered: delivered,
      paid: paid || due <= 0,
      seenDone: seenDone,
    );

    await DatabaseService.saveOrder(order);
    await NotificationService.scheduleOrderReminders(order);

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.order == null ? 'Add Memo' : 'Edit Memo'),
      ),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _text(memo, 'Memo No', required: true),
            _text(name, 'Customer Name', required: true),
            _text(address, 'Address'),
            _text(phone, 'Phone Number', keyboard: TextInputType.phone),
            _text(desc, 'Product / Particular Description', maxLines: 3),
            Row(
              children: [
                Expanded(child: _text(qty, 'Quantity', keyboard: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(child: _text(rate, 'Rate', keyboard: TextInputType.number)),
              ],
            ),
            _text(advance, 'Advance Amount', keyboard: TextInputType.number),
            const SizedBox(height: 8),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    _amountRow('Total', total),
                    _amountRow('Due', due),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            _dateTile('Seen Date', seenDate, () => pickDate(true)),
            _timeTile('Seen Reminder Time', seenTime, () => pickTime(true)),
            _dateTile('Delivery Date', deliveryDate, () => pickDate(false)),
            _timeTile('Delivery Reminder Time', deliveryTime, () => pickTime(false)),
            _text(note, 'Note', maxLines: 2),
            SwitchListTile(
              title: const Text('Delivered'),
              value: delivered,
              onChanged: (v) => setState(() => delivered = v),
            ),
            SwitchListTile(
              title: const Text('Payment Paid'),
              value: paid || due <= 0,
              onChanged: due <= 0 ? null : (v) => setState(() => paid = v),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Save Memo'),
              onPressed: save,
            ),
          ],
        ),
      ),
    );
  }

  Widget _text(TextEditingController c, String label,
      {bool required = false, TextInputType? keyboard, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller: c,
        keyboardType: keyboard,
        maxLines: maxLines,
        onChanged: (_) => setState(() {}),
        validator: required
            ? (v) => v == null || v.trim().isEmpty ? 'Required' : null
            : null,
        decoration: InputDecoration(labelText: label),
      ),
    );
  }

  Widget _dateTile(String title, String value, VoidCallback onTap) {
    return Card(
      elevation: 0,
      child: ListTile(
        title: Text(title),
        subtitle: Text(value.isEmpty ? 'Not selected' : value),
        trailing: const Icon(Icons.calendar_month),
        onTap: onTap,
      ),
    );
  }

  Widget _timeTile(String title, String value, VoidCallback onTap) {
    return Card(
      elevation: 0,
      child: ListTile(
        title: Text(title),
        subtitle: Text(value),
        trailing: const Icon(Icons.access_time),
        onTap: onTap,
      ),
    );
  }

  Widget _amountRow(String label, double value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(value.toStringAsFixed(0),
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ],
    );
  }
}