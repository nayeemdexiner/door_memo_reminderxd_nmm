import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../services/database_service.dart';
import 'add_order_screen.dart';

class OrderDetailsScreen extends StatefulWidget {
  final OrderModel order;
  const OrderDetailsScreen({super.key, required this.order});

  @override
  State<OrderDetailsScreen> createState() => _OrderDetailsScreenState();
}

class _OrderDetailsScreenState extends State<OrderDetailsScreen> {
  late OrderModel order;

  @override
  void initState() {
    super.initState();
    order = widget.order;
  }

  Future<void> update() async {
    await DatabaseService.updateOrder(order);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Memo ${order.memoNo}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => AddOrderScreen(order: order)),
              );
              if (mounted) Navigator.pop(context);
            },
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text('M/S. Chittagong Door',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Digital Memo'),
                  const Divider(),
                  _row('Memo No', order.memoNo),
                  _row('Date', order.orderDate),
                  _row('Customer', order.customerName),
                  _row('Address', order.address),
                  _row('Phone', order.phone),
                  const Divider(),
                  _row('Description', order.description),
                  _row('Quantity', order.quantity.toString()),
                  _row('Rate', order.rate.toStringAsFixed(0)),
                  _row('Total', order.total.toStringAsFixed(0)),
                  _row('Advance', order.advance.toStringAsFixed(0)),
                  _row('Due', order.due.toStringAsFixed(0)),
                  const Divider(),
                  _row('Seen Date', '${order.seenDate} ${order.seenTime}'),
                  _row('Delivery Date', '${order.deliveryDate} ${order.deliveryTime}'),
                  _row('Order Status', order.delivered ? 'Delivered' : 'Pending'),
                  _row('Payment Status', order.paid || order.due <= 0 ? 'Paid' : 'Due'),
                  if (order.note.isNotEmpty) _row('Note', order.note),
                  const SizedBox(height: 30),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Customer Signature'),
                      Text('Shop Signature'),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.check_circle),
            label: Text(order.delivered ? 'Mark as Pending' : 'Mark as Delivered'),
            onPressed: () async {
              order.delivered = !order.delivered;
              await update();
            },
          ),
          OutlinedButton.icon(
            icon: const Icon(Icons.payments),
            label: Text(order.paid ? 'Mark as Due' : 'Mark as Paid'),
            onPressed: () async {
              order.paid = !order.paid;
              await update();
            },
          ),
        ],
      ),
    );
  }

  Widget _row(String left, String right) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 120, child: Text(left, style: const TextStyle(fontWeight: FontWeight.w600))),
          Expanded(child: Text(right.isEmpty ? '-' : right)),
        ],
      ),
    );
  }
}