import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../services/database_service.dart';
import '../services/notification_service.dart';
import 'add_order_screen.dart';
import 'order_details_screen.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List<OrderModel> allOrders = [];
  String query = '';
  String filter = 'All';

  @override
  void initState() {
    super.initState();
    load();
  }

  void load() {
    setState(() => allOrders = DatabaseService.getOrders());
  }

  List<OrderModel> get orders {
    var list = allOrders.where((o) {
      final q = query.toLowerCase();
      return o.memoNo.toLowerCase().contains(q) ||
          o.customerName.toLowerCase().contains(q) ||
          o.phone.toLowerCase().contains(q);
    }).toList();

    if (filter == 'Pending') list = list.where((o) => !o.delivered).toList();
    if (filter == 'Delivered') list = list.where((o) => o.delivered).toList();
    if (filter == 'Due') list = list.where((o) => o.due > 0 && !o.paid).toList();
    if (filter == 'Paid') list = list.where((o) => o.paid || o.due <= 0).toList();

    return list;
  }

  Future<void> toggleDelivered(OrderModel o) async {
    o.delivered = !o.delivered;
    await DatabaseService.updateOrder(o);
    load();
  }

  Future<void> togglePaid(OrderModel o) async {
    o.paid = !o.paid;
    await DatabaseService.updateOrder(o);
    load();
  }

  Future<void> delete(OrderModel o) async {
    await NotificationService.cancelOrderReminders(o.id);
    await DatabaseService.deleteOrder(o.id);
    load();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = orders;

    return Scaffold(
      appBar: AppBar(title: const Text('All Orders')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddOrderScreen()),
          );
          load();
        },
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Search by memo, name, phone',
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (v) => setState(() => query = v),
            ),
          ),
          SizedBox(
            height: 42,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: ['All', 'Pending', 'Delivered', 'Due', 'Paid']
                  .map(
                    (f) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(f),
                        selected: filter == f,
                        onSelected: (_) => setState(() => filter = f),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          Expanded(
            child: filtered.isEmpty
                ? const Center(child: Text('No orders found'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filtered.length,
                    itemBuilder: (context, i) {
                      final o = filtered[i];
                      return Card(
                        elevation: 0,
                        child: ListTile(
                          title: Text('Memo ${o.memoNo} - ${o.customerName}',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text(
                            'Phone: ${o.phone}\nSeen: ${o.seenDate}  Delivery: ${o.deliveryDate}\nDue: ${o.due.toStringAsFixed(0)}',
                          ),
                          isThreeLine: true,
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) async {
                              if (value == 'view') {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => OrderDetailsScreen(order: o),
                                  ),
                                );
                              }
                              if (value == 'edit') {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => AddOrderScreen(order: o),
                                  ),
                                );
                              }
                              if (value == 'delivered') await toggleDelivered(o);
                              if (value == 'paid') await togglePaid(o);
                              if (value == 'delete') await delete(o);
                              load();
                            },
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'view', child: Text('View')),
                              const PopupMenuItem(value: 'edit', child: Text('Edit')),
                              PopupMenuItem(
                                  value: 'delivered',
                                  child: Text(o.delivered ? 'Mark Pending' : 'Mark Delivered')),
                              PopupMenuItem(
                                  value: 'paid',
                                  child: Text(o.paid ? 'Mark Due' : 'Mark Paid')),
                              const PopupMenuItem(value: 'delete', child: Text('Delete')),
                            ],
                          ),
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => OrderDetailsScreen(order: o),
                              ),
                            );
                            load();
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}