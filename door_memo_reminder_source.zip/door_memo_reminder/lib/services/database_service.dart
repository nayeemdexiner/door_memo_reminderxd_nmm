import 'package:hive_flutter/hive_flutter.dart';
import '../models/order_model.dart';

class DatabaseService {
  static const String boxName = 'orders_box';

  static Future<void> init() async {
    await Hive.initFlutter();
    await Hive.openBox(boxName);
  }

  static Box get box => Hive.box(boxName);

  static List<OrderModel> getOrders() {
    return box.values
        .map((item) => OrderModel.fromMap(Map<String, dynamic>.from(item)))
        .toList()
      ..sort((a, b) => b.orderDate.compareTo(a.orderDate));
  }

  static Future<void> saveOrder(OrderModel order) async {
    await box.put(order.id, order.toMap());
  }

  static Future<void> deleteOrder(String id) async {
    await box.delete(id);
  }

  static Future<void> updateOrder(OrderModel order) async {
    await box.put(order.id, order.toMap());
  }
}