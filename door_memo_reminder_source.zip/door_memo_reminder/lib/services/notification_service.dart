import 'dart:io';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../models/order_model.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tzdata.initializeTimeZones();

    const AndroidInitializationSettings androidInit =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings settings =
        InitializationSettings(android: androidInit);

    await plugin.initialize(settings);

    if (Platform.isAndroid) {
      await Permission.notification.request();
      await Permission.scheduleExactAlarm.request();
    }
  }

  static Future<void> scheduleOrderReminders(OrderModel order) async {
    await cancelOrderReminders(order.id);

    if (order.seenDate.isNotEmpty) {
      final seenDateTime = _parseDateTime(order.seenDate, order.seenTime);
      if (seenDateTime != null && seenDateTime.isAfter(DateTime.now())) {
        await _schedule(
          id: _stableId('${order.id}_seen'),
          title: 'Seen Reminder - Memo ${order.memoNo}',
          body:
              '${order.customerName}\nPhone: ${order.phone}\nDue: ${order.due.toStringAsFixed(0)}\n${order.description}',
          dateTime: seenDateTime,
        );
      }
    }

    if (order.deliveryDate.isNotEmpty) {
      final deliveryDateTime =
          _parseDateTime(order.deliveryDate, order.deliveryTime);
      if (deliveryDateTime != null && deliveryDateTime.isAfter(DateTime.now())) {
        await _schedule(
          id: _stableId('${order.id}_delivery'),
          title: 'Delivery Reminder - Memo ${order.memoNo}',
          body:
              '${order.customerName}\nPhone: ${order.phone}\nDue: ${order.due.toStringAsFixed(0)}\n${order.description}',
          dateTime: deliveryDateTime,
        );
      }
    }
  }

  static Future<void> cancelOrderReminders(String orderId) async {
    await plugin.cancel(_stableId('${orderId}_seen'));
    await plugin.cancel(_stableId('${orderId}_delivery'));
  }

  static Future<void> _schedule({
    required int id,
    required String title,
    required String body,
    required DateTime dateTime,
  }) async {
    await plugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(dateTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'memo_reminder_channel',
          'Memo Reminders',
          channelDescription: 'Seen date and delivery date reminders',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          fullScreenIntent: true,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  static DateTime? _parseDateTime(String date, String time) {
    try {
      final d = date.split('-').map(int.parse).toList();
      final t = time.split(':').map(int.parse).toList();
      return DateTime(d[0], d[1], d[2], t[0], t[1]);
    } catch (_) {
      return null;
    }
  }

  static int _stableId(String text) {
    return text.codeUnits.fold(0, (p, e) => (p + e) % 2147483647);
  }
}